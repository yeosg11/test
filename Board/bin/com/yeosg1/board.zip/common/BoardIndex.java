package com.yeosg1.board.common;


public class BoardIndex {
	public static int index = 1;
	

}
